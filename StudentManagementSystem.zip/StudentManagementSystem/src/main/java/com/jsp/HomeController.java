
package com.jsp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.entity.Student;
import com.jsp.service.StudentService;

@Controller // 3.flow enters here and run according to the provided jsp pages
public class HomeController {

	@RequestMapping("/hi")
	public String sayHi() {
		return "hi.jsp";
	}

	// this method will direct to student.jsp
	@RequestMapping("/student")
	public String student() {
		return "student.jsp";
	}

	// this method will store all given values from browser inside an object i.e
	// student object
	@RequestMapping("/register")
	public ModelAndView register() {
		System.out.println("entering register");

		Student s = new Student();
		ModelAndView mv = new ModelAndView(); // model is student obj and view is our jsp page
		mv.setViewName("register.jsp");
		mv.addObject("student", s);
		return mv;
	}

	// this method will get values from browser and prints in console
//	@RequestMapping("/save")
//	public ModelAndView saveStudent(Student s1) {
//		System.out.println("entering saveStudent");
//
//		System.out.println(s1.getName());
//		System.out.println(s1.getPhone());
//		System.out.println(s1.getEmail());
//		System.out.println(s1.getPassword());
//		return new ModelAndView("index.jsp");
//	}

	@Autowired
	private StudentService service;

	// this method will store values inside database
//	@RequestMapping("/save")
//	public ModelAndView saveStudent(Student s1) {
//		System.out.println("entering saveStudent");
//		
//		service.saveStudent(s1);
//		return new ModelAndView("index.jsp");
//		
//	}

	// to store data in database and display it in View.jsp page in browser
	@RequestMapping("/save")
	public ModelAndView saveStudent(Student student) {
		System.out.println("entering saveStudent");
		service.saveStudent(student);
		ModelAndView mv = new ModelAndView("View.jsp");
		List<Student> list = service.getAllstudents();
		mv.addObject("std", list); // to add student list in view.jsp
		return mv;
	}
	
	@RequestMapping("/delete")
	public ModelAndView deleteStudent(@RequestParam int id)
	{
		service.deleteStudent(id);
		ModelAndView mv= new ModelAndView("view.jsp");
		mv.addObject("std",service.getAllstudents());
		return mv;
	}
	@RequestMapping("/update")
    public ModelAndView updateStudent(@RequestParam int id) {
    	Student student = service.getStudentById(id);
    	
    	ModelAndView mv = new ModelAndView();
    	mv.setViewName("edit.jsp");
    	mv.addObject("student",student);
    	return mv;
    }
	
    @RequestMapping("/Edit")
    public ModelAndView editStudent(Student updatedStudent) {
    	service.updateStudent(updatedStudent);
    	ModelAndView mv = new ModelAndView("view.jsp");
    	mv.addObject("std",service.getAllstudents());
    	return mv;
    }

}

