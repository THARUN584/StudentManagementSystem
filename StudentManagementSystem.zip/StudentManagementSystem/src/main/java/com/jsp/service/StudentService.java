package com.jsp.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jsp.entity.Student;
import com.jsp.dao.StudentDao;

@Component
public class StudentService {

	@Autowired
	private StudentDao dao;
	
	public void saveStudent(Student student) {
		dao.saveStudent(student);
	}
	
	public List<Student> getAllstudents(){
		return dao.getAllStudent();
	}
	
	public void deleteStudent(int id) {
		dao.deleteStudent(id);
	}
	public Student getStudentById(int id) {
		return dao.getStudentById(id);
	}
	public void updateStudent(Student student) {
		dao.updateStudent(student);
	}

	
	
}
